@extends('layouts.app')

@section('css')
    {{-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css"> --}}
@endsection

@section('content')
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 my-4">
    <a href="{{ route('pasien_checkup', $data->id) }}" class="btn btn-success btn-sm"><i class="fas fa-user-md"></i> Check Up</a>
    <br>
    <br>
    <div class="table-responsive">
        <table class="table table-bordered table-sm">
            <tr>
                <td width="15%">Nama</td>
                <td>{{$data->nama_awal}} {{$data->nama_ahir}}</td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>{{$data->jenis_kelamin}}</td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>{{$data->tanggal_lahir}}</td>
            </tr>
            <tr>
                <td>BPJS</td>
                <td>{{$data->nomor_bpjs}}</td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>{{$data->alamat}}</td>
            </tr>
            <tr>
                <td>Nomor Telepon</td>
                <td>{{$data->nomor_telepon}}</td>
            </tr>
            <tr>
                <td>Nama Wali</td>
                <td>{{$data->nama_wali}}</td>
            </tr>
        </table>
    </div>
    <hr>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-sm">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Jenis Pemeriksaan</th>
                    <th>Diagnosa</th>
                    <th>Tindakan Medis</th>
                    <th>Resep Obat</th>
                    <th>Tanggal Periksa</th>
                    <th>Setting</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($history_checkup as $index => $value)
                @if($value->id<1)
                <tr>
                    <td colspan="6">Belum ada data</td>
                </tr>
                @else
                <tr>
                    <td>{{$index+1}}</td>
                    <td>{{$value->jenis_pemeriksaan}}</td>
                    <td>{{$value->diagnosa}}</td>
                    <td>{{$value->tindakan_medis}}</td>
                    <td>{{$value->resep_obat}}</td>
                    <td>{{ date("d-m-Y", strtotime($value->created_at)) }}</td>
                    <td>
                        <form action="{{ route('pasien_delete', $value->id) }}" method="post">
                            @csrf
                            @method("DELETE")
                            <button style="float: left;" type="submit" class="btn btn-danger btn-sm mr-2" data-toggle="tooltip" data-placement="left" title="Hapus Data Pasien" onclick="return confirm('Apakah anda yakin menghapus data ini.?')"><i class="fas fa-trash"></i></button>
                        </form>
                        <button style="float: left;" type="button" class="btn btn-warning btn-sm mr-2" data-toggle="modal"
                            data-target="#detail_pemeriksaan_{{$value->id}}" title="Detail"><i class="far fa-eye" data-toggle="tooltip" data-placement="left" title="Detail Check Up"></i></button>

                            <div class="modal fade" id="detail_pemeriksaan_{{$value->id}}" tabindex="-1" role="dialog" aria-labelledby="detail_pemeriksaan_{{$value->id}}" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Detail Pemeriksaan {{$value->pasien->nama_awal}} {{$value->pasien->nama_ahir}}</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                    <div class="table-responsive">
                                                            <table class="table table-bordered table-sm">
                                                                <tr>
                                                                    <td width="15%">Nama</td>
                                                                    <td>{{$data->nama_awal}} {{$data->nama_ahir}}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Tanggal Pemeriksaan</td>
                                                                    <td>{{ date("d-m-Y", strtotime($value->created_at)) }}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Jenis Pemeriksaan</td>
                                                                    <td>{{$value->jenis_pemeriksaan}}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Diagnosa</td>
                                                                    <td>{{$value->diagnosa}}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Tindakan Medis</td>
                                                                    <td>{{$value->tindakan_medis}}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Resep Obat</td>
                                                                    <td>{{$value->resep_obat}}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Dirujuk</td>
                                                                    <td>{{$value->isDirujuk}}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Lokasi Rujukan</td>
                                                                    <td>{{$value->lokasi_rujukan}}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Alasan Dirujuk</td>
                                                                    <td>{{$value->alasan_dirujuk}}</td>
                                                                    </tr>
                                                            </table>
                                                        </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {{-- end modal detail check up --}}
                    </td>
                </tr>
                @endif
                @endforeach
            </tbody>
        </table>
        {{-- {{ $data->links() }} --}}
    </div>
</main>
@endsection

@section('js')
    <script>

        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
    </script>
@endsection 